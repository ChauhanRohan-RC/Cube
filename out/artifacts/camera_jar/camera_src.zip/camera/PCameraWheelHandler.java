package camera;

public interface PCameraWheelHandler {
	void handleWheel(final int delta);
}
