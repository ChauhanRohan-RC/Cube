package camera;

public interface PCameraDragHandler {
	void handleDrag(final double dx, final double dy);
}
