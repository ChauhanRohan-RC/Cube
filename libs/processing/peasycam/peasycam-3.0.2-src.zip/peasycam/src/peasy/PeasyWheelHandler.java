package peasy;

public interface PeasyWheelHandler {
	public void handleWheel(final int delta);
}
